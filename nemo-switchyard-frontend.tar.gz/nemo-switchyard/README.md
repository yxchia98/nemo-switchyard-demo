# NeMo Switchyard - container, route templates, and a live frontend

Everything needed to run [NVIDIA NeMo Switchyard](https://github.com/NVIDIA-NeMo/Switchyard)
`switchyard-server` and see what it is doing: a container build, a template for
every router type it supports, and a single-file React client that talks to a
running server.

The frontend defaults match a `llm_classifier` / `capability` route with `id =
"switchyard"`, `weak = nvidia/nemotron-3.5-lightning:free` and `strong =
nvidia/nemotron-3-ultra-550b-a55b:free`, both on OpenRouter. The container
templates cover the other routers too, including a stage router that can pair
OpenRouter with a self-hosted NIM.

| File | Purpose |
| --- | --- |
| `Dockerfile` | Multi-stage build: cargo-installs `switchyard-server`, ships only the binary |
| `routes.toml.template` | Switchyard route config, with `${VAR}` placeholders |
| `entrypoint.sh` | Renders the template via `envsubst`, validates with `--dry-run`, then serves |
| `docker-compose.yml` | Switchyard + an optional NIM service on the same network |
| `.env.example` | Template for runtime config; copy to `.env` |
| `.dockerignore` | Keeps `.env` out of the build context |
| `routes/` | One template per router type (see Router types below) |
| `render.sh` | Render/validate any template on the host |
| `serve/serve.mjs` | Serves the frontend and reverse-proxies `/v1/*` to Switchyard (no CORS) |
| `../switchyard_live_client.html` | Single-file React client for a running server |

## Config format: TOML, not YAML

The `switchyard-server` binary reads an explicit **TOML** file. There is no YAML
schema for the Switchyard server. (YAML is used by a different NVIDIA product,
the NeMo Agent Toolkit, whose `config.yml` has an `llms:` section.)

Switchyard's TOML has three layers:

1. `[llm_clients.*]` - an endpoint plus its wire format
2. `[targets.*]` - a model, bound to a client; `id` is the real model name sent upstream
3. `[routes.*]` - the routing algorithm; its `id` is the model name your agent requests

## Quick start

Nothing is hardcoded in the image. Copy the template, fill it in, and run:

```bash
cp .env.example .env
$EDITOR .env          # set OPENROUTER_API_KEY, NIM_BASE_URL, NIM_MODEL

docker compose up --build
curl http://localhost:4000/health
```

Compose picks up `.env` via `env_file:`. Note that a service-level
`environment:` block takes precedence over `env_file:`, so the compose file
deliberately omits one — add keys there only to force an override.

Without Compose, pass the same file to `docker run`:

```bash
docker build -t switchyard:0.2 .

docker run --rm -p 127.0.0.1:4000:4000 \
  --env-file .env \
  switchyard:0.2
```

Override one value without editing the file (`-e` beats `--env-file`):

```bash
docker run --rm -p 127.0.0.1:4000:4000 \
  --env-file .env \
  -e SWITCHYARD_PICKER=capable_first \
  switchyard:0.2
```

### Env-file gotchas

* **Do not quote values.** `--env-file` treats everything after `=` literally,
  so `OPENROUTER_API_KEY="sk-or-x"` includes the quote characters in the key.
  The entrypoint fails fast if it detects a leading quote.
* **No variable expansion.** `FOO=${BAR}` is not interpolated inside an env file.
* **Keep `.env` out of git and out of the image.** It is in `.dockerignore`;
  add it to `.gitignore` too.
* For real deployments prefer Docker secrets or a Kubernetes Secret mounted as
  env vars over a plaintext file on disk.

Then point any OpenAI-compatible client at the proxy and request the **route id**
as the model:

```bash
curl http://localhost:4000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"switchyard/stage","messages":[{"role":"user","content":"hello"}]}'
```

The response carries the routing decision in headers:

```
x-model-router-selected-model: nvidia/nemotron-3.5-lightning:free
x-model-router-rationale: fall-through selected ... (confidence 0.000)
```

## Environment variables

Defaults for non-secret values live in `entrypoint.sh` as `${VAR:=default}`
rather than in the Dockerfile, so there is one place to read them and anything
in your env file overrides them. `SWITCHYARD_PORT` is the sole exception — it is
also an `ENV` because `EXPOSE` and `HEALTHCHECK` are evaluated against the image
environment at build time.

| Variable | Default | Notes |
| --- | --- | --- |
| `OPENROUTER_API_KEY` | *(required)* | Entrypoint exits if unset |
| `OPENROUTER_BASE_URL` | `https://openrouter.ai/api/v1` | |
| `OPENROUTER_MODEL` | `nvidia/nemotron-3.5-lightning:free` | Efficient tier |
| `NIM_BASE_URL` | `http://nim:8000/v1` | Capable tier endpoint |
| `NIM_MODEL` | `nvidia/nemotron-3-ultra` | Set to whatever your NIM serves |
| `NIM_API_KEY` | `EMPTY` | Placeholder; most self-hosted NIMs don't enforce auth |
| `SWITCHYARD_ROUTE_ID` | `switchyard/stage` | The model name clients request |
| `SWITCHYARD_PICKER` | `efficient_first` | `capable_first` favours quality over cost |
| `SWITCHYARD_CONFIDENCE_THRESHOLD` | `0.5` | Signal strength needed to switch tiers |
| `SWITCHYARD_RECENT_WINDOW` | `3` | How many recent turns of signals are scored |
| `SWITCHYARD_HOST` | `0.0.0.0` | Bind inside the container; publish to loopback |
| `SWITCHYARD_PORT` | `4000` | Also an image `ENV` for `EXPOSE`/`HEALTHCHECK` |
| `RUST_LOG` | `info` | |
| `NGC_API_KEY` | *(needed for bundled `nim`)* | Omit if NIM runs elsewhere |

`base_url` cannot be read from the environment by Switchyard itself — only API
keys support that, via `api_key_env`. That is why the config is a template
rendered by `envsubst` at startup rather than a static file.

## Router types

Switchyard supports four route types. Pick one with `SWITCHYARD_TEMPLATE`, or
serve them all at once with `all_routes.toml.template` — one TOML file can
declare many routes, and each route `id` appears as its own model on
`GET /v1/models`, so a client switches strategy just by changing the model name.

| Template | `type` | Decides from | Extra cost per decision |
| --- | --- | --- | --- |
| `passthrough.toml.template` | `passthrough` | nothing — fixed target | none |
| `random.toml.template` | `random` | weighted coin flip | none |
| `stage_router.toml.template` | `stage_router` | tool results, errors, progress | ~none |
| `llm_classifier_capability.toml.template` | `llm_classifier` + `mode="capability"` | a judge reading the request | one judge call |
| `llm_classifier_escalation.toml.template` | `llm_classifier` + `mode="escalation"` | a judge reading the weak answer | one judge call per session |

Note the escalation router is not its own `type` — it is `llm_classifier` with
`mode = "escalation"`. In v0.1 it was a separate `escalation_router`; if you
find older examples using that, they target the deprecated Python server.

Vocabulary differs between routers and this trips people up: `stage_router`
names its tiers `efficient_target` / `capable_target`, while `llm_classifier`
uses `weak_target` / `strong_target`. The combined template maps both onto the
same two underlying targets.

### Choosing between them

Start with `stage_router` for coding agents — it is near-free and needs no
tuning. Move to `capability` mode when the *request text* rather than execution
history should decide. Use `escalation` when you want every task to start cheap
and promote only when demonstrably stuck; note its promotion is **sticky**,
whereas `stage_router` moves back and forth. Keep the two `passthrough` routes
deployed alongside whatever you choose: if an automatic route misbehaves,
hitting `switchyard/capable` directly tells you whether the router or the
upstream is at fault.

### Calibrating the classifier

`base_threshold` is **required** in capability mode and upstream ships no
recommended value, because the `p_solve` distribution depends on your model
pairing and task shape. The judge also infers a task domain and applies a
`threshold_step` stricter bar where it is less confident, giving a staircase
(e.g. 0.75 familiar / 0.85 / 0.95 unfamiliar). Measure on a sample of real
traffic; the `0.75` default here is a placeholder, not advice.

### Rendering and validating

```bash
./render.sh routes/all_routes.toml.template              # print it
./render.sh routes/random.toml.template --dry-run        # validate it
```

`--dry-run` checks schema, env lookups, target references and route
construction without binding a socket, so a typo'd target reference fails
immediately instead of on the first request.

### One caveat on `random`

The weighted syntax in `random.toml.template` is **unverified** — the docs say
random "selects among targets using optional relative weights" but no official
weighted example was available when this was written. Validate with `--dry-run`
before relying on it; if rejected, the error names the expected shape. Dropping
the `weights` line gives a uniform split, which is the safer default.

## How the stage router decides

Per turn it scores recent tool activity: severe errors, repeated unproductive
work or long exploration push toward `capable`; steady edits, especially once
tests pass, favour `efficient`. A single signal is usually not decisive —
corroborating signals must cross `confidence_threshold`. Inconclusive turns fall
back to the `picker` default. No judge-model call is made on the default path,
so routing adds little latency.

Unlike the escalation router, stage routing is **bidirectional** — a session can
move back down to the efficient tier later in a task.

## Frontend client

A single-file React page, `switchyard_live_client.html`, is a thin live client for
a running `switchyard-server`. Nothing is simulated: it discovers your routes via
`GET /v1/models`, sends real `POST /v1/chat/completions` requests, and displays
the routing decision from the `x-model-router-selected-model` and
`x-model-router-rationale` response headers. It also keeps a session ledger
(spend vs. an always-strong baseline) and a latency comparison across routes.

Serve it with the bundled server, which hosts the page *and* reverse-proxies
`/v1/*` to Switchyard so the browser only ever talks to one origin:

```bash
node serve/serve.mjs                                    # -> switchyard on localhost:4000
node serve/serve.mjs --target http://10.0.0.42:4000     # remote server
```

Then open <http://localhost:8080/> and set **Base URL** to `/v1`.

The relative base URL is the important part. Switchyard sends no CORS headers,
and browsers hide custom response headers from JavaScript without
`Access-Control-Expose-Headers` - so a direct cross-origin call returns a valid
completion whose routing headers read `null`, which looks like a broken router
when only the display data is missing. Proxying through the same origin sidesteps
this entirely. See `serve/README.md` for details and a Caddy alternative.

The page loads React, Babel and ECharts from public CDNs, so it needs internet on
first load; your Switchyard server itself can stay fully internal.

## Things worth knowing before production

- **Switchyard is pre-alpha.** NVIDIA labels it experimental and not for
  production use; the config schema is expected to change before v1.0. The
  `SWITCHYARD_VERSION` build arg is pinned for that reason — re-validate
  `routes.toml` when you bump it.
- **No auth, TLS or rate limiting.** Port 4000 is deliberately published to
  `127.0.0.1`. Put authentication, TLS and rate limits in a real gateway before
  exposing this to a team.
- **The free OpenRouter endpoint is rate limited**, and mid-task tier switching
  has been observed to disrupt tool-calling context consistency in some agent
  frameworks. Raise `confidence_threshold` if you see that, and evaluate on your
  own workload before trusting the cost numbers.
- **First build is slow** (compiling a Rust project from source). The cargo
  registry cache mounts make rebuilds much faster.

## Sources

- [Switchyard repo](https://github.com/NVIDIA-NeMo/Switchyard) and [Getting Started](https://nvidia-nemo.github.io/Switchyard/getting_started/)
- [Core concepts / route types](https://nvidia-nemo.github.io/Switchyard/core_concepts/)
- [Nemotron 3.5 Lightning (free) on OpenRouter](https://openrouter.ai/nvidia/nemotron-3.5-lightning:free)
- [NVIDIA developer blog: routing agent workloads](https://developer.nvidia.com/blog/route-ai-agent-workloads-across-models-with-nvidia-nemo-switchyard/)
