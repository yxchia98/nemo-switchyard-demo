#!/bin/sh
# Render and validate a route template on the host, without starting anything.
#
#   ./render.sh                       # render the active template to stdout
#   ./render.sh routes/all_routes.toml.template
#   ./render.sh routes/random.toml.template --dry-run   # also validate
#
# Requires envsubst (gettext) and, for --dry-run, switchyard-server on PATH.
set -eu

TEMPLATE="${1:-routes.toml.template}"
[ "${1:-}" ] && shift || true

[ -f "$TEMPLATE" ] || { echo "no such template: $TEMPLATE" >&2; exit 1; }

[ -f .env ] && { set -a; . ./.env; set +a; }

# Same non-secret defaults as entrypoint.sh.
: "${OPENROUTER_BASE_URL:=https://openrouter.ai/api/v1}"
: "${OPENROUTER_MODEL:=nvidia/nemotron-3.5-lightning:free}"
: "${NIM_BASE_URL:=http://nim:8000/v1}"
: "${NIM_MODEL:=nvidia/nemotron-3-ultra}"
: "${JUDGE_MODEL:=nvidia/nemotron-3.5-lightning:free}"
: "${SWITCHYARD_ROUTE_ID:=switchyard/stage}"
: "${SWITCHYARD_PICKER:=efficient_first}"
: "${SWITCHYARD_CONFIDENCE_THRESHOLD:=0.5}"
: "${SWITCHYARD_RECENT_WINDOW:=3}"
: "${CLASSIFIER_BASE_THRESHOLD:=0.75}"
: "${CLASSIFIER_THRESHOLD_STEP:=0.1}"
: "${ESCALATION_CONFIRMATIONS:=2}"
export OPENROUTER_BASE_URL OPENROUTER_MODEL NIM_BASE_URL NIM_MODEL JUDGE_MODEL \
       SWITCHYARD_ROUTE_ID SWITCHYARD_PICKER SWITCHYARD_CONFIDENCE_THRESHOLD \
       SWITCHYARD_RECENT_WINDOW CLASSIFIER_BASE_THRESHOLD \
       CLASSIFIER_THRESHOLD_STEP ESCALATION_CONFIRMATIONS

if [ "${1:-}" = "--dry-run" ]; then
    OUT=$(mktemp)
    trap 'rm -f "$OUT"' EXIT
    envsubst < "$TEMPLATE" > "$OUT"
    : "${OPENROUTER_API_KEY:=dry-run-placeholder}"; export OPENROUTER_API_KEY
    : "${NIM_API_KEY:=EMPTY}"; export NIM_API_KEY
    switchyard-server --config "$OUT" --dry-run
    echo "OK: $TEMPLATE is valid"
else
    envsubst < "$TEMPLATE"
fi
