#!/usr/bin/env node
/**
 * serve.mjs - one command to serve the Switchyard demo page with no CORS problems.
 *
 * Serves the HTML file AND reverse-proxies /v1/* to your Switchyard server from
 * the same origin. Because the browser only ever talks to this server, CORS never
 * applies and the x-model-router-* decision headers are always readable.
 *
 *   node serve.mjs                                  # page :8080 -> switchyard localhost:4000
 *   node serve.mjs --port 9000 --target http://10.0.0.42:4000
 *   SWITCHYARD_URL=https://sy.internal:4000 node serve.mjs
 *
 * In the page, set Base URL to  /v1   (relative - that is what keeps it same-origin).
 */
import http from "node:http";
import https from "node:https";
import { readFile } from "node:fs/promises";
import { createReadStream, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

const PORT = Number(arg("port", process.env.PORT || 8080));
const TARGET = (arg("target", process.env.SWITCHYARD_URL || "http://localhost:4000")).replace(/\/+$/, "");
// Resolve the demo page. An explicit --page/PAGE wins; otherwise search the
// usual spots so the script works whether it sits beside the HTML or in serve/.
const PAGE_OVERRIDE = arg("page", process.env.PAGE || "");
const CANDIDATES = [
  "switchyard_live_client.html",
  "../switchyard_live_client.html",
  "../../switchyard_live_client.html",
  "index.html",
  "../index.html",
];
function resolvePage() {
  if (PAGE_OVERRIDE) return path.resolve(process.cwd(), PAGE_OVERRIDE);
  for (const c of CANDIDATES) {
    const f = path.resolve(HERE, c);
    if (existsSync(f)) return f;
  }
  return null;
}
const PAGE = resolvePage();

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
};

// Headers that must not be forwarded verbatim on either leg.
const HOP_BY_HOP = new Set([
  "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
  "te", "trailer", "transfer-encoding", "upgrade", "host",
]);

function proxy(req, res) {
  const upstream = new URL(TARGET + req.url);
  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (!HOP_BY_HOP.has(k.toLowerCase())) headers[k] = v;
  }
  headers.host = upstream.host;

  const lib = upstream.protocol === "https:" ? https : http;
  const proxied = lib.request(
    {
      protocol: upstream.protocol,
      hostname: upstream.hostname,
      port: upstream.port || (upstream.protocol === "https:" ? 443 : 80),
      method: req.method,
      path: upstream.pathname + upstream.search,
      headers,
    },
    (up) => {
      const out = {};
      for (const [k, v] of Object.entries(up.headers)) {
        if (!HOP_BY_HOP.has(k.toLowerCase())) out[k] = v;
      }
      // Same-origin already, but harmless and helps if the page is opened from elsewhere.
      out["access-control-expose-headers"] =
        "x-model-router-selected-model, x-model-router-rationale, x-model-router-route";
      res.writeHead(up.statusCode || 502, out);
      up.pipe(res);
    }
  );

  proxied.on("error", (err) => {
    const msg =
      err.code === "ECONNREFUSED"
        ? `Cannot reach Switchyard at ${TARGET} - is the server running?`
        : `Upstream error: ${err.message}`;
    console.error(`  ! ${msg}`);
    res.writeHead(502, { "content-type": "application/json; charset=utf-8" });
    res.end(JSON.stringify({ error: { message: msg, type: "proxy_error" } }));
  });

  req.pipe(proxied);
}

const server = http.createServer(async (req, res) => {
  // Proxy every OpenAI-compatible path straight through.
  if (req.url.startsWith("/v1/")) {
    console.log(`  -> ${req.method} ${req.url}  =>  ${TARGET}${req.url}`);
    return proxy(req, res);
  }

  if (req.url === "/healthz") {
    res.writeHead(200, { "content-type": "text/plain" });
    return res.end("ok\n");
  }

  // Anything else: serve the demo page.
  if (req.url === "/" || req.url === "/index.html") {
    if (!PAGE) {
      res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
      return res.end(
        "Could not find the demo HTML file.\n\n" +
        "Looked for:\n  " + CANDIDATES.join("\n  ") + "\n" +
        "relative to " + HERE + "\n\n" +
        "Pass it explicitly:  node serve.mjs --page /path/to/switchyard_live_client.html\n"
      );
    }
    try {
      const html = await readFile(PAGE);
      res.writeHead(200, { "content-type": MIME[".html"], "cache-control": "no-store" });
      return res.end(html);
    } catch (err) {
      res.writeHead(500, { "content-type": "text/plain" });
      return res.end(`Cannot read page at ${PAGE}\n${err.message}\n`);
    }
  }

  // Static siblings, path-traversal guarded.
  const rel = decodeURIComponent(req.url.split("?")[0]).replace(/^\/+/, "");
  if (!PAGE) { res.writeHead(404, { "content-type": "text/plain" }); return res.end("Not found\n"); }
  const root = path.dirname(PAGE);
  const file = path.resolve(root, rel);
  if (!file.startsWith(root)) {
    res.writeHead(403, { "content-type": "text/plain" });
    return res.end("Forbidden\n");
  }
  createReadStream(file)
    .on("open", () =>
      res.writeHead(200, { "content-type": MIME[path.extname(file)] || "application/octet-stream" })
    )
    .on("error", () => {
      res.writeHead(404, { "content-type": "text/plain" });
      res.end("Not found\n");
    })
    .pipe(res);
});

server.listen(PORT, () => {
  console.log(`
  Switchyard demo
  ---------------
  Page          http://localhost:${PORT}/
  Proxying      /v1/*  ->  ${TARGET}/v1/*
  Serving       ${PAGE || "(page not found - pass --page /path/to/file.html)"}

  In the page, set Base URL to  /v1  (relative, keeps it same-origin - no CORS).
  Ctrl-C to stop.
`);
});
