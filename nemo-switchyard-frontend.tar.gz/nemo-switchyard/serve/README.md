# Serving the Switchyard demo page

The page is a single self-contained HTML file: `switchyard_live_client.html`.
It has no build step. There are three ways to run it, easiest first.

---

## Option 1 — open the file directly

Download `switchyard_live_client.html` and double-click it.

Works, but you will hit **CORS**: the browser is on `file://` and your Switchyard
server is on `http://localhost:4000`, so that is a cross-origin request. Switchyard
sends no CORS headers, so either the request is refused outright, or it succeeds
with a `200` whose `x-model-router-*` decision headers are invisible to JavaScript.

Fine for looking at the layout. Not fine for actually driving your proxy.

---

## Option 2 — `serve.mjs` (recommended)

One command, no CORS at all, nothing to install. Needs Node 18+.

```bash
node serve.mjs
```

Then open <http://localhost:8080/> and set **Base URL** to `/v1`.

That relative URL is the whole trick. The page and the API are on the *same origin*,
so CORS never applies and every routing header is readable. No Caddy, no
`Access-Control-*` configuration, no proxy to reason about.

### Pointing at a remote Switchyard

```bash
node serve.mjs --target http://10.0.0.42:4000
node serve.mjs --target https://switchyard.internal.dell.com
SWITCHYARD_URL=https://switchyard.internal.dell.com node serve.mjs
```

### All options

| Flag | Env | Default | Meaning |
|---|---|---|---|
| `--port` | `PORT` | `8080` | Port to serve the page on |
| `--target` | `SWITCHYARD_URL` | `http://localhost:4000` | Your Switchyard server |
| `--page` | `PAGE` | auto-detected | Path to the HTML file |

`https://` targets work; the script picks the right transport from the scheme.
`/healthz` returns `ok` for container probes.

If the upstream is unreachable you get a `502` saying
`Cannot reach Switchyard at <target> - is the server running?`
rather than a silent hang.

---

## Option 3 — any static server + the Base URL as-is

```bash
python3 -m http.server 8080     # then open http://localhost:8080/switchyard_live_client.html
npx serve .
```

This serves the page over `http://` but does **not** proxy, so `http://localhost:4000/v1`
is still cross-origin and you are back to the CORS problem. Use this only if you
already terminate CORS somewhere else — the page's troubleshooting section has a
Caddyfile for that case.

---

## The page needs internet on first load

React, Babel and ECharts come from `unpkg.com` and `cdn.jsdelivr.net`. On a fully
air-gapped machine the page renders blank. `serve.mjs` serves any file sitting
beside the HTML, so you can vendor them: download the four scripts, drop them in
the same folder, and rewrite the four `src="https://..."` attributes to local
filenames.

Note this is separate from Switchyard reachability — the *libraries* need the
public internet, your *proxy* does not.

---

## Settings persistence

Endpoint, route id, model ids and prices are saved in `localStorage` under
`switchyard-live-client-v2`, per browser and per origin. Switching from
`file://` to `http://localhost:8080` starts with fresh defaults, and clearing
site data resets everything. The API key field is stored the same way, so treat
a shared browser accordingly.
